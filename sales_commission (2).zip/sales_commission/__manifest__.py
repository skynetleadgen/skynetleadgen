{
    "name": "Sales Commission",
    "version": "1.0",
    "summary": "Calculate sales commission for salespeople",
    "author": "Your Name",
    "category": "Sales",
    "depends": ["sale_management"],
    "data": [
        "views/sale_commission_view.xml","security/ir.model.access.csv",
    ],
    
    "installable": True,
    "application": True,
}
